function profilepopup () {
    var profilepopup = document.getElementById('profilepopup');
    var clicks = this.clicks;
    if (clicks) {
        profilepopup.style.display = 'none';
    } else {
        profilepopup.style.display = 'block';
    }
    this.clicks = !clicks;
}

function opencategories () {
    var categories = document.getElementById('categories');
    var clicks = this.clicks;
    if (clicks) {
        categories.style.left = '-100%';
    } else {
        categories.style.left = '0%';
        categories.style.transition = '0.5s ease'
    }
    this.clicks = !clicks;
}

function cartopen() {
    var minicart = document.getElementById('minicart');
    minicart.style.right = '0px';
}

function cartclose() {
    var minicart = document.getElementById('minicart');
    minicart.style.right = '-600px';
}

// Image Selection


// Footer Selection


$(document).ready(function () {
    $(".data").hide();
    $('.name').on('click', function () {
        var attri = $(this).attr('value');
        $(".data").hide();
        $("#" + attri).show();
    });
});
